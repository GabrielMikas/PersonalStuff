package com.cardKeeper.cardKeeperAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardKeeperApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
