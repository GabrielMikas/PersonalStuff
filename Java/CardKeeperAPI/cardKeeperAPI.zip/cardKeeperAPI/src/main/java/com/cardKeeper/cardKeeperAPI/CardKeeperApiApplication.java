package com.cardKeeper.cardKeeperAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardKeeperApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CardKeeperApiApplication.class, args);
	}

}
